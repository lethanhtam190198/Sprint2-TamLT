package com.example.bookstore.service;

import com.example.bookstore.model.Discount;

import java.util.List;

public interface IDiscountService {
    List<Discount>findAllDiscount();
}
