package com.example.bookstore.common;

public class MyConstants {
    public static final String MY_EMAIL = "sangnguyenjp97@gmail.com";

    // Replace password!!
    public static final String MY_PASSWORD = "jjjaqbmsumgnhkhg";

    // And receiver!
    public static final String MAIL_RECEIVER= "";
}
